package com.patterns.adapter.common.apple;

import com.patterns.adapter.common.Image;

public class Caramel {
    public void init() {
        System.out.println("Initialized Caramel");
    }

    public void render(Image image) {
        System.out.println("Applying Caramel Filter");
    }
}
