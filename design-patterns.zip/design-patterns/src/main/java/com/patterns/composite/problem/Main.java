package com.patterns.composite.problem;

public class Main {
    public static void main(String[] args) {
        Group group1 = new Group();
        group1.add(new Shape()); // imaginary Square
        group1.add(new Shape()); // imaginary Square

        Group group2 = new Group();
        group2.add(new Shape()); // imaginary Circle
        group2.add(new Shape()); // imaginary Circle

        Group group3 = new Group();
        group3.add(group1);
        group3.add(group2);
        group3.render();
    }
}
