package com.patterns.adapter.solution;

import com.patterns.adapter.common.Filter;
import com.patterns.adapter.common.Image;
import com.patterns.adapter.common.apple.Caramel;

public class CaramelAdapter extends Caramel implements Filter {
    @Override
    public void apply(Image image) {
        init();
        render(image);
    }
}
