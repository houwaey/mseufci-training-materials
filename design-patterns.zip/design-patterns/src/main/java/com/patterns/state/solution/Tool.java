package com.patterns.state.solution;

public interface Tool {
    void mouseDown();
    void mouseUp();
}
