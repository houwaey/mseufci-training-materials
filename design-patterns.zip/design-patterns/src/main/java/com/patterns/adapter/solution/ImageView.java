package com.patterns.adapter.solution;

import com.patterns.adapter.common.Filter;
import com.patterns.adapter.common.Image;

public class ImageView {
    private Image image;

    public ImageView(Image image) {
        this.image = image;
    }

    public void apply(Filter filter) {
        filter.apply(image);
    }
}
