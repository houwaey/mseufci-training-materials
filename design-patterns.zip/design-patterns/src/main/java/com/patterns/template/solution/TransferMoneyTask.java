package com.patterns.template.solution;

public class TransferMoneyTask extends Task {
    @Override
    public void doExecute() {
        System.out.println("Transfer Money");
    }
}
