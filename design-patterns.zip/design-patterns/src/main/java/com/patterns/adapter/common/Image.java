package com.patterns.adapter.common;

public class Image {
}
