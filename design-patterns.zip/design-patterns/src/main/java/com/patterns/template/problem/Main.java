package com.patterns.template.problem;

public class Main {
}
