package com.patterns.decorator.solution;

public interface Stream {
    void write(String data);
}
