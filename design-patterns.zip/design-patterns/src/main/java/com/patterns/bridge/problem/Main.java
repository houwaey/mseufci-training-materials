package com.patterns.bridge.problem;

public class Main {
    public static void main(String[] args) {
        RemoteControl sonyBasic = new SonyRemoteControl();
        sonyBasic.turnOn();
        sonyBasic.turnOff();

        AdvancedRemoteControl sonyAdvanced = new SonyAdvancedRemoteControl();
        sonyAdvanced.turnOn();
        sonyAdvanced.setChannel(10);
        sonyAdvanced.turnOff();

    }
}
