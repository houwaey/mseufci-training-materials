package com.patterns.template.solution;

public class GenerateReportTask extends Task {
    @Override
    public void doExecute() {
        System.out.println("Generate Report");
    }
}
