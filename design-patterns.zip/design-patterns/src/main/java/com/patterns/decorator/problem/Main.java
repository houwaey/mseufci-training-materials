package com.patterns.decorator.problem;

public class Main {
    public static void main(String[] args) {
//        CloudStream cloudStream = new CloudStream();
        CloudStream cloudStream = new CompressedCloudStream();
//        CloudStream cloudStream = new EncryptedCloudStream();
        cloudStream.write("Here's some data");
    }
}
