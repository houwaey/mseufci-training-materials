package com.patterns.bridge.solution;

public class SonyTV implements Device {
    @Override
    public void turnOn() {
        System.out.println("Sony: Turn On");
    }

    @Override
    public void turnOff() {
        System.out.printf("Sony: Turn Off");
    }

    @Override
    public void setChannel(int number) {
        System.out.println("Sony: Set Channel");
    }
}
