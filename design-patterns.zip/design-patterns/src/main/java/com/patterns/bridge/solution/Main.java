package com.patterns.bridge.solution;

public class Main {
    public static void main(String[] args) {
//        RemoteControl remoteControl = new RemoteControl(new SonyTV());
        RemoteControl remoteControl = new AdvancedRemoteControl(new SonyTV());
        remoteControl.turnOn();
    }
}
