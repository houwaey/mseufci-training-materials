package com.patterns.template.problem;

public class AuditTrail {
    public void record() {
        System.out.println("Audit");
    }
}
