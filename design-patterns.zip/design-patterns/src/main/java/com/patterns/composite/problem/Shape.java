package com.patterns.composite.problem;

public class Shape {
    public void render() {
        System.out.println("Render Shape");
    }
}
