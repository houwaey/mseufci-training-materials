package com.patterns.composite.solution;

public interface Component {
    void render();
    //void move(); TODO: add this method
}
