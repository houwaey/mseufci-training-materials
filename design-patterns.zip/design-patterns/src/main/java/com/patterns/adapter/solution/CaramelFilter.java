package com.patterns.adapter.solution;

import com.patterns.adapter.common.Filter;
import com.patterns.adapter.common.Image;
import com.patterns.adapter.common.apple.Caramel;

public class CaramelFilter implements Filter {
    private Caramel caramel;

    public CaramelFilter(Caramel caramel) {
        this.caramel = caramel;
    }

    @Override
    public void apply(Image image) {
        caramel.init();
        caramel.render(image);
    }
}
