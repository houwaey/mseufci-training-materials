package com.patterns.strategy.problem;

public class Main {
    public static void main(String[] args) {
        ImageStorage imageStorage = new ImageStorage("jpeg", "high-contrast");
        imageStorage.store("AnyFileName");
    }
}
