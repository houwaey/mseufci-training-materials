package com.patterns.bridge.problem;

public abstract class AdvancedRemoteControl extends RemoteControl {
    public abstract void setChannel(int number);
}
