package com.patterns.bridge.problem;

public class SonyAdvancedRemoteControl extends AdvancedRemoteControl {
    @Override
    public void setChannel(int number) {
        System.out.println("Sony Advanced: Set Channel");
    }

    @Override
    public void turnOn() {
        System.out.println("Sony Advanced: Turn On");
    }

    @Override
    public void turnOff() {
        System.out.println("Sony Advanced: Turn Off");
    }
}
