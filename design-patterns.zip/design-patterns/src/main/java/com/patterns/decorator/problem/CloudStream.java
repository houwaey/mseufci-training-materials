package com.patterns.decorator.problem;

public class CloudStream {
    public void write(String data) {
        System.out.println("Storing " + data);
    }
}
