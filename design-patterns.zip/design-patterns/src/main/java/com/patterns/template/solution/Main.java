package com.patterns.template.solution;

public class Main {
    public static void main(String[] args) {
        Task task = new TransferMoneyTask();
        task.execute();

        task = new GenerateReportTask();
        task.execute();
    }
}
