package com.patterns.adapter.common;

import com.patterns.adapter.common.Image;

public interface Filter {
    void apply(Image image);
}
